import express from 'express'
import verifyLogin from '../controllers/verifyLogin.js'

const userRouter = express.Router()

userRouter.post('/login', verifyLogin)

export default userRouter;